package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class EnterpriseOnboardingWizardTest {

    private lateinit var database: NovaDatabase
    private lateinit var repository: NovaRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, NovaDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        repository = NovaRepository(
            dao = database.appDao(),
            workflowDao = database.workflowDao(),
            workspaceDao = database.workspaceDao(),
            auditLogDao = database.auditLogDao(),
            agentRegistryDao = database.agentRegistryDao(),
            workspaceOnboardingDao = database.workspaceOnboardingDao()
        )
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testEnterpriseProfileAndWorkflowPreferencesPersistence() = runBlocking {
        // Given an enterprise onboarding profile with custom workflow preferences
        val customProfile = CompanyProfileEntity(
            id = 1,
            companyName = "Apex Global Logistics",
            industry = "Logistics & Supply Chain",
            primaryBottleneck = "Cross-border customs verification & fleet dispatch",
            targetReductionPercent = 80,
            activeAgents = "Executive Risk Copilot, Nova Operations Engine, Financial Anomaly Analyst",
            customInstructions = "Strict SOC2 and GDPR compliance. Auto-approve fuel authorizations under $2,500.",
            isConfigured = true,
            lastUpdated = System.currentTimeMillis()
        )

        val customWorkflowConfig = BusinessWorkflowConfig(
            companyName = "Apex Global Logistics",
            industry = "Logistics & Supply Chain",
            operationalBottleneck = "Cross-border customs verification & fleet dispatch",
            workloadReductionGoalPct = 80,
            autoApprovalThresholdDollars = 2500.0,
            maxRiskAutoApprovePct = 15,
            emergencyHumanOverride = true
        )

        // When saving the enterprise configuration
        repository.saveCompanyProfile(customProfile)
        repository.updateBusinessConfig(customWorkflowConfig)

        // Then verify the company profile is saved and marked configured
        val savedProfile = repository.companyProfile.first()
        assertNotNull(savedProfile)
        assertEquals("Apex Global Logistics", savedProfile?.companyName)
        assertEquals("Logistics & Supply Chain", savedProfile?.industry)
        assertTrue(savedProfile?.isConfigured == true)
        assertEquals(80, savedProfile?.targetReductionPercent)

        // And verify workflow preferences
        val savedConfig = repository.businessWorkflowConfig.first()
        assertNotNull(savedConfig)
        assertEquals(2500.0, savedConfig.autoApprovalThresholdDollars, 0.01)
        assertEquals(15, savedConfig.maxRiskAutoApprovePct)
        assertTrue(savedConfig.emergencyHumanOverride)
    }

    @Test
    fun testAgentPermissionLevelsAndRiskCustomization() = runBlocking {
        // Given customized agent permission levels from Step 3 of the wizard
        val execAgent = AgentRegistryEntity(
            agentId = "ag_rcos_exec_custom",
            workspaceId = "ws_default",
            agentName = "Executive Risk Copilot",
            agentDescription = "Evaluates strategic risk and approves high-dollar transactions",
            agentType = AgentType.EXECUTIVE_AGENT.name,
            status = AgentStatus.ACTIVE.name,
            capabilityProfile = "READ_DATA,ANALYZE_DATA,GENERATE_REPORTS,REQUEST_APPROVAL,ACCESS_FINANCIAL_DATA",
            permissionLevel = AccessLevel.WORKFLOW_ADMIN.name,
            riskClassification = AgentRiskLevel.HIGH.name,
            modelTier = "GEMINI_2_5_PRO"
        )

        val opsAgent = AgentRegistryEntity(
            agentId = "ag_rcos_ops_custom",
            workspaceId = "ws_default",
            agentName = "Nova Operations Engine",
            agentDescription = "Automates operational workflows and task dispatch",
            agentType = AgentType.OPERATIONS_AGENT.name,
            status = AgentStatus.ACTIVE.name,
            capabilityProfile = "READ_DATA,EXECUTE_WORKFLOW,CREATE_WORKFLOW,SEND_COMMUNICATION",
            permissionLevel = AccessLevel.REGULAR_STAFF.name,
            riskClassification = AgentRiskLevel.LOW.name,
            modelTier = "GEMINI_2_5_FLASH"
        )

        val auditAgent = AgentRegistryEntity(
            agentId = "ag_rcos_audit_custom",
            workspaceId = "ws_default",
            agentName = "Compliance & Security Auditor",
            agentDescription = "Observability and immutable audit logs watchdog",
            agentType = AgentType.COMPLIANCE_AGENT.name,
            status = AgentStatus.ACTIVE.name,
            capabilityProfile = "READ_DATA,ANALYZE_DATA,GENERATE_REPORTS",
            permissionLevel = AccessLevel.READ_ONLY.name,
            riskClassification = AgentRiskLevel.CRITICAL.name,
            modelTier = "GEMINI_2_5_PRO"
        )

        // When inserting/updating agents configured in onboarding
        repository.insertAgent(execAgent)
        repository.insertAgent(opsAgent)
        repository.insertAgent(auditAgent)

        // Then verify the agents are registered with exact customized permission levels
        val agents = repository.getWorkspaceAgents("ws_default").first()
        assertTrue(agents.isNotEmpty())

        val retrievedExec = agents.find { it.agentId == "ag_rcos_exec_custom" }
        assertNotNull(retrievedExec)
        assertEquals(AccessLevel.WORKFLOW_ADMIN.name, retrievedExec?.permissionLevel)
        assertEquals(AgentRiskLevel.HIGH.name, retrievedExec?.riskClassification)

        val retrievedOps = agents.find { it.agentId == "ag_rcos_ops_custom" }
        assertNotNull(retrievedOps)
        assertEquals(AccessLevel.REGULAR_STAFF.name, retrievedOps?.permissionLevel)
        assertEquals(AgentRiskLevel.LOW.name, retrievedOps?.riskClassification)

        val retrievedAudit = agents.find { it.agentId == "ag_rcos_audit_custom" }
        assertNotNull(retrievedAudit)
        assertEquals(AccessLevel.READ_ONLY.name, retrievedAudit?.permissionLevel)
        assertEquals(AgentRiskLevel.CRITICAL.name, retrievedAudit?.riskClassification)
    }

    @Test
    fun testNewUserRequiresOnboardingUntilConfigured() = runBlocking {
        // Initial state before configuration
        val initialProfile = repository.companyProfile.first()
        // If not configured, user should be directed to onboarding wizard
        val needsOnboarding = initialProfile == null || !initialProfile.isConfigured
        assertTrue("New enterprise user must require onboarding before main dashboard access", needsOnboarding)

        // After completing onboarding
        val configured = CompanyProfileEntity(
            id = 1,
            companyName = "Enterprise Client Corp",
            industry = "Cross-Industry Workload",
            primaryBottleneck = "Document Processing",
            targetReductionPercent = 50,
            activeAgents = "Executive Risk Copilot",
            customInstructions = "Default rules",
            isConfigured = true
        )
        repository.saveCompanyProfile(configured)

        val updatedProfile = repository.companyProfile.first()
        assertTrue(updatedProfile?.isConfigured == true)
    }
}
