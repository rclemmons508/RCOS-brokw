# RCOS AI Gateway — Free Cloudflare Worker

This replaces Firebase Cloud Functions so RCOS does **not** require the Firebase Blaze plan.

## What it does

Android app → Cloudflare Worker → Gemini API

The Android app sends its Firebase ID token. The Worker verifies that token using Firebase Authentication before it can use the Gemini API. The Gemini API key is stored as a Cloudflare Worker secret and is never placed in the APK.

Cloudflare's Workers Free plan currently includes up to 100,000 requests/day. Gemini also has a Free Tier with model-specific limits. Actual Gemini limits are controlled by Google AI Studio/Gemini API and can change.

## Phone-only deployment

1. Create/sign into a free Cloudflare account.
2. Open **Workers & Pages** → **Create** → **Start with Hello World**.
3. Name the Worker exactly:
   `rcos-ai-gateway`
4. Open the Worker editor and replace the starter code with the contents of `src/index.js`.
5. Deploy it.
6. Open the Worker **Settings → Variables and Secrets**.
7. Add a secret named exactly:
   `GEMINI_API_KEY`
8. Paste the Gemini API key you created in Google AI Studio into that secret. Do not put the key in the Worker source code or GitHub.
9. Add another secret named exactly `FIREBASE_WEB_API_KEY`. Use the RCOS project browser/web API key from Google Cloud credentials.
10. Deploy/save the Worker again.

The app is already configured for:
`https://rcos-ai-gateway.rclemmons1021.workers.dev`

If Cloudflare gives your Worker a different URL, change the `BACKEND_URL` constant in `GeminiClient.kt` before building the APK.

## Security

Do not put the Gemini key in the Android project, APK, GitHub repository, or screenshots. Cloudflare secrets are encrypted and are not shown after they are stored.
