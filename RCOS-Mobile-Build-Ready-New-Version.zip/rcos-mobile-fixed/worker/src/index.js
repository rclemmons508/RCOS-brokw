const PROJECT_ID = "rcos-2897c";
const DEFAULT_TEXT_MODEL = "gemini-3.7-flash";
const DEFAULT_REASONING_MODEL = "gemini-3.7-flash";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Authorization, Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json; charset=utf-8",
};

function response(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: corsHeaders,
  });
}

function normalizeModel(model, operation) {
  if (!model || model === "gemini-3.5-flash" || model === "gemini-2.0-flash") {
    return operation === "deepReasoning" ? DEFAULT_REASONING_MODEL : DEFAULT_TEXT_MODEL;
  }
  if (model === "gemini-3.1-pro-preview" || model === "gemini-2.5-pro" || model === "gemini-3.7-pro") {
    return DEFAULT_REASONING_MODEL;
  }
  return model;
}

async function verifyFirebaseToken(request, env) {
  const header = request.headers.get("Authorization") || "";
  if (!header.startsWith("Bearer ")) {
    throw new Error("Missing Firebase authentication token.");
  }

  const idToken = header.slice("Bearer ".length).trim();
  if (!idToken || !env.FIREBASE_WEB_API_KEY) {
    throw new Error("Firebase authentication is not configured on the backend.");
  }

  const verifyResponse = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(env.FIREBASE_WEB_API_KEY)}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ idToken }),
    }
  );

  const data = await verifyResponse.json();
  if (!verifyResponse.ok || !Array.isArray(data.users) || !data.users.length) {
    throw new Error("Invalid or expired Firebase authentication token.");
  }

  const user = data.users[0];
  if (user.disabled) {
    throw new Error("Firebase user account is disabled.");
  }

  return user;
}

function buildContents(operation, body) {
  if (operation === "generateChat") {
    const contents = [];
    for (const item of Array.isArray(body.history) ? body.history : []) {
      contents.push({
        role: item.role === "user" ? "user" : "model",
        parts: [{ text: String(item.text || "") }],
      });
    }
    contents.push({
      role: "user",
      parts: [{ text: String(body.userMessage || "") }],
    });
    return contents;
  }

  if (operation === "transcribeAudio") {
    return [{
      role: "user",
      parts: [
        {
          text: body.prompt ||
            "Transcribe this audio recording accurately. Then provide a brief summary and action items.",
        },
        {
          inline_data: {
            mime_type: body.mimeType || "audio/wav",
            data: body.audioBase64,
          },
        },
      ],
    }];
  }

  return [{
    role: "user",
    parts: [{ text: String(body.prompt || "") }],
  }];
}

function extractText(data) {
  const candidates = Array.isArray(data?.candidates) ? data.candidates : [];
  return candidates
    .flatMap((candidate) => candidate?.content?.parts || [])
    .map((part) => part?.text || "")
    .join("")
    .trim() || "No text content generated.";
}

async function callGemini(body, env) {
  const operation = body.operation || "generateText";
  const model = normalizeModel(body.model, operation);

  if (operation === "transcribeAudio" && (!body.audioBase64 || !body.mimeType)) {
    throw new Error("Audio data and MIME type are required.");
  }

  const requestBody = {
    contents: buildContents(operation, body),
  };

  if (body.systemInstruction) {
    requestBody.systemInstruction = {
      parts: [{ text: String(body.systemInstruction) }],
    };
  }

  const geminiResponse = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": env.GEMINI_API_KEY,
      },
      body: JSON.stringify(requestBody),
    }
  );

  const data = await geminiResponse.json();
  if (!geminiResponse.ok) {
    const message = data?.error?.message || "Gemini API request failed.";
    throw new Error(message);
  }

  return { text: extractText(data), model };
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    if (request.method !== "POST") {
      return response({ success: false, error: "POST required." }, 405);
    }

    try {
      const user = await verifyFirebaseToken(request, env);
      const body = await request.json();
      const result = await callGemini(body, env);

      return response({
        success: true,
        text: result.text,
        model: result.model,
        userId: user.localId,
      });
    } catch (error) {
      console.error("RCOS AI gateway error:", error);
      const message = error?.message || "AI backend request failed.";
      const status = /token|authentication|unauthorized|jwt/i.test(message) ? 401 : 500;
      return response({ success: false, error: message }, status);
    }
  },
};
